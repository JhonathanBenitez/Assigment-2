/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student;

class GraduateStudent extends Student {
    private String thesisTopic;

    public GraduateStudent(String name, String studentID, double gpa, String thesisTopic) {
        super(name, studentID, gpa);
        if (thesisTopic == null || thesisTopic.trim().isEmpty()) {
            throw new IllegalArgumentException("Thesis topic cannot be empty.");
        }
        this.thesisTopic = thesisTopic.trim();
    }

    @Override
    public void displayStudentInfo() {
        System.out.printf("Graduate Student: %s, ID: %s, GPA: %.2f, Thesis: %s%n", name, studentID, gpa, thesisTopic);
    }
}
