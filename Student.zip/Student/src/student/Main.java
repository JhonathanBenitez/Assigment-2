/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        StudentManager manager = new StudentManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nStudent Records Management System");
            System.out.println("1. Add a Student");
            System.out.println("2. Save Student Records");
            System.out.println("3. Load and Display Student Records");
            System.out.println("4. Search Student by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter student name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter student ID (6-digit number): ");
                        String studentID = scanner.nextLine();
                        System.out.print("Enter GPA (0.0 - 4.0): ");
                        double gpa = scanner.nextDouble();
                        scanner.nextLine();

                        System.out.println("Is this student undergraduate (1) or graduate (2)?");
                        int type = scanner.nextInt();
                        scanner.nextLine();

                        if (type == 1) {
                            System.out.print("Enter Year Level (1-4): ");
                            int yearLevel = scanner.nextInt();
                            manager.addStudent(new UndergraduateStudent(name, studentID, gpa, yearLevel));
                        } else if (type == 2) {
                            System.out.print("Enter Thesis Topic: ");
                            String thesisTopic = scanner.nextLine();
                            manager.addStudent(new GraduateStudent(name, studentID, gpa, thesisTopic));
                        } else {
                            System.out.println("Invalid choice.");
                        }
                        break;

                    case 2:
                        manager.saveStudentsToFile();
                        break;
                    case 3:
                        manager.loadStudentsFromFile();
                        manager.displayAllStudents();
                        break;
                    case 4:
                        System.out.print("Enter Student ID to search: ");
                        String searchID = scanner.nextLine();
                        manager.searchStudentByID(searchID);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
        }
    }
}
