/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package student;

import java.io.*;
import java.util.*;

abstract class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    protected String name;
    protected String studentID;
    protected double gpa;

    public Student(String name, String studentID, double gpa) throws IllegalArgumentException {
        this.name = validateAndFormatName(name);
        this.studentID = validateStudentID(studentID);
        this.gpa = validateGPA(gpa);
    }

    private String validateAndFormatName(String name) {
        if (name == null || !name.matches("^[A-Za-z]+(\\s[A-Za-z]+)*$")) {
            throw new IllegalArgumentException("Invalid name format. Only letters and spaces are allowed.");
        }
        return Arrays.stream(name.trim().split(" "))
                     .map(word -> word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase())
                     .reduce((a, b) -> a + " " + b)
                     .orElse("");
    }

    private String validateStudentID(String studentID) {
        if (studentID == null || !studentID.matches("\\d{6}")) {
            throw new IllegalArgumentException("Invalid student ID. Must be exactly 6 digits.");
        }
        return studentID;
    }

    private double validateGPA(double gpa) {
        if (gpa < 0.0 || gpa > 4.0) {
            throw new IllegalArgumentException("Invalid GPA. Must be between 0.0 and 4.0.");
        }
        return gpa;
    }

    public String getStudentID() {
        return studentID;
    }

    public abstract void displayStudentInfo();
}
