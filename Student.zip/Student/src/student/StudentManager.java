/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

class StudentManager {
    private ArrayList<Student> students = new ArrayList<>();
    private static final String FILE_NAME = "students.dat";

    public void addStudent(Student student) {
        students.add(student);
    }

    public void saveStudentsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(students);
            System.out.println("Student records saved successfully.");
        } catch (IOException e) {
            System.err.println("Error saving student records: " + e.getMessage());
        }
    }

    public void loadStudentsFromFile() throws IOException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            students = (ArrayList<Student>) ois.readObject();
            System.out.println("Student records loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("No previous records found.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading student records: " + e.getMessage());
        }
    }

    public void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No student records available.");
        } else {
            students.forEach(Student::displayStudentInfo);
        }
    }

    public void searchStudentByID(String studentID) {
        for (Student student : students) {
            if (student.getStudentID().equals(studentID)) {
                student.displayStudentInfo();
                return;
            }
        }
        System.out.println("Student not found.");
    }
}

