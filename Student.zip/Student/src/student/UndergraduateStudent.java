/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student;

class UndergraduateStudent extends Student {
    private int yearLevel;

    public UndergraduateStudent(String name, String studentID, double gpa, int yearLevel) {
        super(name, studentID, gpa);
        if (yearLevel < 1 || yearLevel > 4) {
            throw new IllegalArgumentException("Year level must be between 1 and 4.");
        }
        this.yearLevel = yearLevel;
    }

    @Override
    public void displayStudentInfo() {
        System.out.printf("Undergraduate Student: %s, ID: %s, GPA: %.2f, Year Level: %d%n", name, studentID, gpa, yearLevel);
    }
}